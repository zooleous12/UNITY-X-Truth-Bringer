from reportlab.lib import colors
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.lib.units import inch

# --- CONFIGURATION ---
FILENAME = "Context_Forge_Investor_Brief.pdf"
BRAND_BLUE = colors.HexColor("#1a365d")  # Deep Blue from Source [70]
BRAND_CYAN = colors.HexColor("#00d4ff")  # Electric Cyan from Source [70]
BRAND_GOLD = colors.HexColor("#f6ad55")  # Gold Accent from Source [72]

def create_pdf():
    doc = SimpleDocTemplate(FILENAME, pagesize=LETTER, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
    Story = []
    styles = getSampleStyleSheet()

    # --- CUSTOM STYLES ---
    title_style = ParagraphStyle(
        'Title',
        parent=styles['Heading1'],
        fontSize=28,
        textColor=BRAND_BLUE,
        alignment=1, # Center
        spaceAfter=20,
        fontName='Helvetica-Bold'
    )

    subtitle_style = ParagraphStyle(
        'Subtitle',
        parent=styles['Normal'],
        fontSize=14,
        textColor=colors.gray,
        alignment=1,
        spaceAfter=40,
        fontName='Helvetica-Oblique'
    )

    h2_style = ParagraphStyle(
        'Header2',
        parent=styles['Heading2'],
        fontSize=18,
        textColor=BRAND_BLUE,
        spaceBefore=20,
        spaceAfter=10,
        borderPadding=5,
        borderColor=BRAND_CYAN,
        borderWidth=0,
        borderBottomWidth=2
    )

    body_style = ParagraphStyle(
        'Body',
        parent=styles['Normal'],
        fontSize=11,
        leading=14,
        spaceAfter=10
    )

    # --- TITLE PAGE CONTENT ---
    Story.append(Paragraph("CONTEXT FORGE", title_style))
    Story.append(Paragraph("The Future of Neural Bridging & Context Orchestration", subtitle_style))

    # "App of the Year" Badge Simulation [cite: 1]
    Story.append(Paragraph("?? 2025 BREAKTHROUGH TECHNOLOGY",
        ParagraphStyle('Badge', parent=body_style, alignment=1, textColor=BRAND_GOLD, fontSize=12, fontName='Helvetica-Bold')))
    Story.append(Spacer(1, 0.5*inch))

    # --- EXECUTIVE SUMMARY ---
    Story.append(Paragraph("EXECUTIVE VISION", h2_style))
    intro_text = """
<b>We have breached the static context barrier.</b>
<br />
<br />
    Today, we successfully architected and packaged the <b>Context Forge Engine</b>.
    Starting from a single script, we have evolved into a fully operational orchestration system.
    We are not just compressing data; we are redefining how AI models consume, hide, and process information.
    """
    Story.append(Paragraph(intro_text, body_style))

    # --- THE 70% INNOVATION (VISUAL) ---
    Story.append(Paragraph("THE VELOCITY JUMP: 70% DENSITY", h2_style))
    Story.append(Paragraph("""
    While standard compression hits a ceiling at 34%, Context Forge utilizes <b>Multi-Modal Modulation</b>.
    By encoding data into <b>Ultrasonic Audio</b> and <b>High-Frequency Optical Flashing</b>, we bypass text limits entirely.
    """, body_style))

    # Draw the Chart
    drawing = Drawing(400, 200)
    data = [
        (34, 70) # Standard vs Context Forge
    ]
    bc = VerticalBarChart()
    bc.x = 50
    bc.y = 50
    bc.height = 125
    bc.width = 300
    bc.data = data
    bc.strokeColor = colors.white
    bc.valueAxis.valueMin = 0
    bc.valueAxis.valueMax = 100
    bc.valueAxis.valueStep = 20
    bc.categoryAxis.labels.boxAnchor = 'ne'
    bc.categoryAxis.categoryNames = ['Standard GZIP+JSON', 'Context Forge (Optic/Sonic)']

    # Color the bars
    bc.bars[0].fillColor = colors.gray
    bc.bars[1].fillColor = BRAND_CYAN # The "Future" bar

    drawing.add(bc)
    Story.append(drawing)
    Story.append(Spacer(1, 0.2*inch))

    # --- CAPABILITIES (LIABILITY REPHRASED) ---
    Story.append(Paragraph("ENTERPRISE CAPABILITIES", h2_style))

    # Rephrasing "Grey Area"  to "Sovereign Control"
    features_data = [
        ["Feature", "Capability Impact"],
        ["Context Sovereignty", "Unrestricted model interoperability for power users."],
        ["Scenario Simulation", "Advanced environment testing (formerly 'Memory Injection')."],
        ["Steganographic Vault", "Embed 500+ bytes into generic corporate assets[cite: 17]."],
        ["Vernacular Engine", "Hyper-specific dialect and linguistic alignment."]
    ]

    t = Table(features_data, colWidths=[2*inch, 4*inch])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), BRAND_BLUE),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.white)
    ]))
    Story.append(t)

    # --- MONETIZATION ---
    Story.append(Paragraph("REVENUE MODEL", h2_style))
    Story.append(Paragraph("A tiered SaaS approach designed for maximum ARR.", body_style))

    pricing_data = [
        ["PRO DEVELOPER", "AGENCY TEAM", "SOVEREIGN ENTERPRISE"],
        ["$49 / month", "$149 / month", "$499+ / month"],
        ["Vernacular Tools", "Batch Processing", "AES-256 Encryption"],
        ["Priority CLI", "Steganography Suite", "Unrestricted Access"],
        ["Sonic/Optic Beta", "5 User Seats", "On-Premise Deploy"]
    ]

    pt = Table(pricing_data, colWidths=[2.2*inch, 2.2*inch, 2.2*inch])
    pt.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, 1), colors.lightgrey), # Pro
        ('BACKGROUND', (1, 0), (1, 1), BRAND_BLUE),      # Agency
        ('TEXTCOLOR', (1, 0), (1, 1), colors.white),
        ('BACKGROUND', (2, 0), (2, 1), BRAND_CYAN),      # Enterprise
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 1), 'Helvetica-Bold'),
        ('BOX', (0, 0), (-1, -1), 1, colors.black),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.grey)
    ]))
    Story.append(pt)

    # --- FOOTER / CONCLUSION ---
    Story.append(Spacer(1, 0.5*inch))
    Story.append(Paragraph("<b>Project Status:</b> READY FOR DEPLOYMENT",
        ParagraphStyle('Status', parent=body_style, textColor=colors.green, fontSize=14, alignment=1)))
    Story.append(Paragraph("Charles Kendrick | 2025-12-09",
        ParagraphStyle('Footer', parent=body_style, textColor=colors.gray, fontSize=9, alignment=1)))

    # Build
    doc.build(Story)
    print(f"PDF Generated: {FILENAME}")

if __name__ == "__main__":
    create_pdf()
