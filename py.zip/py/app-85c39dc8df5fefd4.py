# PROPERTY OF CHARLES KENDRICK 2026
import os

# Force pure-Python protobuf to avoid compiled extension issues on Python 3.14
os.environ.setdefault("PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION", "python")

from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)

GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head><title>LLM Interface</title></head>
<body>
    <h1>Lightweight LLM Interface</h1>
    <textarea id="prompt" placeholder="Enter your prompt..." rows="4" cols="50"></textarea><br>
    <button onclick="sendToGemini()">Send to Gemini</button>
    <button onclick="sendToOpenAI()">Send to OpenAI</button>
    <div id="response" style="margin-top:20px; padding:10px; border:1px solid #ccc;"></div>

    <script>
    async function sendToGemini() {
        const prompt = document.getElementById('prompt').value;
        const response = await fetch('/gemini', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({prompt})
        });
        const data = await response.json();
        document.getElementById('response').innerHTML = `<strong>Gemini:</strong> ${data.text || data.error}`;
    }

    async function sendToOpenAI() {
        const prompt = document.getElementById('prompt').value;
        const response = await fetch('/openai', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({prompt})
        });
        const data = await response.json();
        document.getElementById('response').innerHTML = `<strong>OpenAI:</strong> ${data.text || data.error}`;
    }
    </script>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/gemini', methods=['POST'])
def gemini_api():
    try:
        prompt = request.get_json().get('prompt', '')
        if not prompt or not GEMINI_API_KEY:
            return jsonify({'error': 'Missing prompt or API key'})

        resp = requests.post(
            f'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={GEMINI_API_KEY}',
            headers={'Content-Type': 'application/json'},
            json={
                'contents': [
                    {
                        'parts': [
                            {'text': prompt}
                        ]
                    }
                ]
            },
            timeout=30
        )

        if resp.status_code != 200:
            return jsonify({'error': f'Gemini API error: {resp.status_code} {resp.text}'}), resp.status_code

        data = resp.json()
        text = (
            data.get('candidates', [{}])[0]
                .get('content', {})
                .get('parts', [{}])[0]
                .get('text', '')
        )
        if not text:
            return jsonify({'error': 'Gemini API returned no text'}), 502

        return jsonify({'text': text})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/openai', methods=['POST'])
def openai_api():
    try:
        prompt = request.get_json().get('prompt', '')
        if not prompt or not OPENAI_API_KEY:
            return jsonify({'error': 'Missing prompt or API key'})

        response = requests.post('https://api.openai.com/v1/chat/completions',
            headers={'Authorization': f'Bearer {OPENAI_API_KEY}', 'Content-Type': 'application/json'},
            json={'model': 'gpt-3.5-turbo', 'messages': [{'role': 'user', 'content': prompt}], 'max_tokens': 150})

        if response.status_code == 200:
            return jsonify({'text': response.json()['choices'][0]['message']['content']})
        return jsonify({'error': f'API error: {response.status_code}'})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True, port=5000)