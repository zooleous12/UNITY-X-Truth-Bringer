#!/usr/bin/env python3
"""
AI Context Orchestrator - Command Line Interface
Encode and decode context data using multiple compression strategies.
PROPERTY OF CHARLES KENDRICK 12/9/25
"""

import argparse
import os
import sys
from pathlib import Path

# Import our modules
from encode_context import main as encode_main, DEFAULT_PLACEHOLDERS
from decode_context import main as decode_main


def cmd_encode(args):
    """Handle encode command"""
    print("🔄 Encoding context data...")
    
    # Set environment variable if custom source provided
    if args.source:
        os.environ["CONTEXT_SOURCE_PATH"] = args.source
    
    try:
        encode_main()
        print("✅ Encoding completed successfully!")
    except Exception as e:
        print(f"❌ Encoding failed: {e}")
        sys.exit(1)


def cmd_decode(args):
    """Handle decode command"""
    print("🔄 Decoding context data...")
    
    try:
        decode_main()
        print("✅ Decoding completed successfully!")
    except Exception as e:
        print(f"❌ Decoding failed: {e}")
        sys.exit(1)


def cmd_test(args):
    """Handle test command - full encode/decode cycle"""
    print("🧪 Running full encode/decode test cycle...")
    
    # Create test data if it doesn't exist
    test_file = "test_context.json"
    if not os.path.exists(test_file):
        test_data = """{
  "user_profile": {
    "name": "${USER_NAME}",
    "location": "${USER_LOCATION}",
    "background": ["Test User", "AI Orchestration Testing"]
  },
  "test_info": {
    "timestamp": "2024-12-09",
    "purpose": "CLI Test Cycle",
    "status": "active"
  }
}"""
        with open(test_file, 'w') as f:
            f.write(test_data)
        print(f"📝 Created test file: {test_file}")
    
    # Set test file as source
    os.environ["CONTEXT_SOURCE_PATH"] = test_file
    
    try:
        # Encode
        print("1️⃣ Encoding test data...")
        encode_main()
        
        # Decode
        print("2️⃣ Decoding test data...")
        decode_main()
        
        print("✅ Test cycle completed successfully!")
        print("📁 Check Whisper_Deck/ directory for output files")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        sys.exit(1)


def cmd_info(args):
    """Display system information"""
    print("ℹ️  AI Context Orchestrator Information")
    print("=" * 50)
    print(f"📂 Working Directory: {os.getcwd()}")
    print(f"📁 Output Directory: Whisper_Deck/")
    print(f"🔧 Default Placeholders:")
    for key, value in DEFAULT_PLACEHOLDERS.items():
        print(f"   {key} → {value}")
    
    # Check for PIL availability
    try:
        from PIL import Image
        print("🖼️  PIL/Pillow: ✅ Available (PNG embedding supported)")
    except ImportError:
        print("🖼️  PIL/Pillow: ❌ Not available (PNG embedding disabled)")
    
    # Check for existing files
    whisper_dir = Path("Whisper_Deck")
    if whisper_dir.exists():
        files = list(whisper_dir.glob("*"))
        if files:
            print(f"📄 Existing files in Whisper_Deck/:")
            for file in files:
                size = file.stat().st_size
                print(f"   {file.name} ({size} bytes)")
        else:
            print("📄 No files in Whisper_Deck/ directory")
    else:
        print("📄 Whisper_Deck/ directory does not exist")


def main():
    parser = argparse.ArgumentParser(
        description="AI Context Orchestrator - Encode/decode context data with multiple compression strategies",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s encode                    # Encode using default source file
  %(prog)s encode -s mydata.json     # Encode specific source file
  %(prog)s decode                    # Decode existing encoded data
  %(prog)s test                      # Run full encode/decode test cycle
  %(prog)s info                      # Show system information
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Encode command
    encode_parser = subparsers.add_parser('encode', help='Encode context data')
    encode_parser.add_argument('-s', '--source', help='Source file path (overrides default search)')
    encode_parser.set_defaults(func=cmd_encode)
    
    # Decode command
    decode_parser = subparsers.add_parser('decode', help='Decode context data')
    decode_parser.set_defaults(func=cmd_decode)
    
    # Test command
    test_parser = subparsers.add_parser('test', help='Run full encode/decode test cycle')
    test_parser.set_defaults(func=cmd_test)
    
    # Info command
    info_parser = subparsers.add_parser('info', help='Show system information')
    info_parser.set_defaults(func=cmd_info)
    
    # Parse arguments
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Execute command
    args.func(args)


if __name__ == "__main__":
    main()