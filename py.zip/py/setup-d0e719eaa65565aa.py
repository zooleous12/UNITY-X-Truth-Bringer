#!/usr/bin/env python3
"""
Setup script for AI Context Orchestrator
PROPERTY OF CHARLES KENDRICK 12/9/25
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="ai-context-orchestrator",
    version="1.0.0",
    author="Charles Kendrick",
    author_email="",
    description="AI Context Orchestrator - Encode/decode context data with multiple compression strategies",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/zooleous12/ai-orchestrator",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "ai-orchestrator=cli:main",
        ],
    },
)