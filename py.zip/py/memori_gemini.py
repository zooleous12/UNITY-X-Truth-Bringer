import os
import sys
import logging
import signal
from datetime import datetime
import google.generativeai as genai
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from memori import Memori

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

# Check API key
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    logging.error("GEMINI_API_KEY not set")
    sys.exit(1)

# Configure Gemini
genai.configure(api_key=API_KEY)

# Database setup
engine = create_engine("sqlite:///memori.sqlite", pool_pre_ping=True, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)

# Setup Memori
mem = Memori(conn=SessionLocal).gemini.register(genai)
mem.config.storage.build()
mem.attribution(entity_id="charles", process_id="gemini-bot")

# Model setup
model = genai.GenerativeModel("gemini-2.5-flash")

# Signal handling for graceful exit
_running = True
def _stop(sig, frame):
    logging.info("Stopping...")
    global _running
    _running = False
signal.signal(signal.SIGINT, _stop)

# Create a chat to keep history
chat = model.start_chat(history=[])

# Main chat loop
logging.info("Gemini + Memori ready. Type 'exit' or 'quit' to stop.")
with SessionLocal() as session:
    while _running:
        try:
            user_input = input("You: ").strip()
        except EOFError:
            break
        
        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit"}:
            break

        try:
            stream = chat.send_message(user_input, stream=True)
            for chunk in stream:
                if chunk.text:
                    print(chunk.text, end="", flush=True)
            print()
            mem.config.storage.adapter.commit()
        except Exception:
            logging.exception("Generation failed")
            session.rollback()

logging.info("Done.")
