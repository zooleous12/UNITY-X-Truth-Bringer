/**
 * @license lucide-react v0.542.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

export { default } from './arrow-up-0-1.js';
//# sourceMappingURL=arrow-up-01.js.map
