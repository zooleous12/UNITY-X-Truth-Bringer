/**
 * @license lucide-react v0.542.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

export { default } from './square-arrow-left.js';
//# sourceMappingURL=arrow-left-square.js.map
